let scoreString = localStorage.getItem('score');
const score = JSON.parse(scoreString);
function printScore() {
    document.querySelector('.js-score')
        .innerHTML = `Wins: ${score.Wins}, Losses: ${score.Losses}, Ties: ${score.Ties}`;
}
printScore();
let user = 'rock';
function generateCPU() {
    let move = Math.random();
    if (move < (1 / 3) && move >= 0) {
        move = 'rock';
    }
    else if (move >= (1 / 3) && move < (2 / 3)) {
        move = 'paper';
    }
    else {
        move = 'scissors';
    }
    return move;
}
function RPS(user) {
    console.log(user);
    let CPU = generateCPU();
    console.log(CPU);
    document.querySelector('.js-WL')
        .innerHTML = `You 
                    ${document.querySelector(`.${user}`).innerHTML} 
                    ${document.querySelector(`.${CPU}`).innerHTML} Computer`;
    if (
        (user === 'rock' && CPU === 'scissors') ||
        (user === 'paper' && CPU === 'rock') ||
        (user === 'scissors' && CPU === 'paper')
    ) {
        score.Wins += 1;
        document.querySelector('.js-result').innerHTML = 'You Win.';
    }
    else if (user === CPU) {
        score.Ties += 1;
        document.querySelector('.js-result').innerHTML = 'You Tied.';
    }
    else {
        score.Losses += 1;
        document.querySelector('.js-result').innerHTML = 'You Lost.';
    }
    console.log(score); printScore();
    localStorage.setItem('score', JSON.stringify(score));
}
function ResetScore() {
    score.Losses = 0; score.Ties = 0; score.Wins = 0;
    console.log(score); printScore();
    localStorage.setItem('score', JSON.stringify(score));
}

document.body.addEventListener('keydown',(event) => {
    if(event.key === 'r'){RPS('rock');}
    else if(event.key === 'p'){RPS('paper');}
    else if(event.key === 's'){RPS('scissors');}
}); //could also do addEvent click and run another

/*If Else Condition Short Cut:
    condition ? if true: else;
    could save in a varible
  GUARD OPERATOR:
    Can store in varible & say something like
    condition && if True statement 
    the && blocks from the other side if false 
    and lets it go through if true
  DEFAULT OPERATOR:
    Similar to guard operator but if left side is true
    we do not need to check right side and it goes through
    and allowed to be stored in varibles
    condition || else -> if true chooses condition
    if false chooses else
*/
var autoStop = true;
let iD;
function AutoPlay(){
    if (autoStop) {
        iD = setInterval(function () {
            const user = generateCPU();
            RPS(user);
        }, 1000);
        autoStop = false;
        document.querySelector('.auto').innerHTML = 'Stop Play';
    }
   else{
    clearInterval(iD);
    autoStop = true;
    document.querySelector('.auto').innerHTML = 'Auto Play';
   }
}
function Stop(){
    clearInterval(autoStop);
}