import './App.css'; //can import file instead of linking it
import { Person } from './Person';

function App() {
  const name = "Myles";
  return (<div className="App">
    <Person
      name='Myles'
      email= 'mh916@cox.net'
      age={19}
      isMarried={false}
      friends={['Isacc','Chris']}
    />
  </div>);
}


export default App;
