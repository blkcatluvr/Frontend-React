export const Tasks = (props) => {
    return (
    <div>
        <h1 style={{color: props.complete && "green"}}>{props.taskName}</h1>
        <button onClick={() => props.completeTask(props.id)}>Complete Task</button>
        <button onClick={() => props.deleteTask(props.id)}>Delete Task</button>
    </div>
    )
}
