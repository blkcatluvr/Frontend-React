export const Users = (props) => {
    return(<h1>{props.name}{props.age}</h1>);
  };
export const Planets = (props) => {
    return (
        <p>{props.name}</p>
    )
}