import './App.css'; //can import file instead of linking it
import {BrowserRouter as Router, Route, Routes,Link } from 'react-router-dom';
import { useState,createContext } from 'react';
import {Home} from "./pages/Home"; import { Profile } from './pages/Profile';
import { Navbar } from './pages/Navbar'; import {Contact} from './pages/Contact';
import {QueryClient, QueryClientProvider} from "@tanstack/react-query"

export const AppContext = createContext();
//query is read, mutation mutation is create/update/delete
function App() {
  const client = new QueryClient({defaultOptions: {
    queries:{refetchOnWindowFocus:false,}
  }});
  const [userName, setUserName] = useState("Myles");
  return (<div className="App">
    <QueryClientProvider client = {client}>
      <AppContext.Provider value={{ userName, setUserName }}>
        <Router>
          <Navbar />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="*" element={<h1>Page Not Found</h1>} />
          </Routes>
        </Router>
      </AppContext.Provider>
    </QueryClientProvider>
 
  </div>);
}


export default App;
