import './App.css'; //can import file instead of linking it
import Axios from "axios"
import { useState,useEffect } from 'react';


function App() {

  const [obj, setObj] = useState(null);
  const [inputVal, setinputVal] = useState("");
  const inputChange = (event) => {setinputVal(event.target.value);}

  const fetchAge = (name) => {
    Axios.get(`https://api.agify.io/?name=${name}`).then((res) => setObj(res.data))
  }


  return (<div className="App">
    <input placeholder='Input Name' onChange={inputChange}/>
    <button onClick={() => fetchAge(inputVal)}>Predict Age</button>
    <h1>Predicted Age: {obj?.age}</h1> {/*Accesses Objects Age if its not Null*/}
  </div>);
}


export default App;
