import './App.css';

function App() {
  //called JSX that mixes JS and HTML Script hence why we can return div element
  const name = "Myles"; // can display varible names
  const header = <h1>Hobbs</h1> // can input html in a varible and display it in HTML
  const age = 19; const email = ' mhobbs8343@gmail.com '; 
  const contact = (<div>{age}{email}</div>);
  return (
  <div className="App">
    <h1>{name}</h1>
    {header}
    {contact}{contact} {/*Shortens Code and Makes it prettier*/}
    <GetNameComponent namE= "Myles" agE ={19}/> {/*Component*/}
    <GetNameComponent namE= "Isacc" agE ={20}/>
    <Job salary={17.50} position="Intern" company="KBR" />
  </div>);
}

const GetName = () => {return "myles"}; //JS Function
const props = {namE: "Myles",agE: 19 };
const GetNameComponent = (props) => {return (
<div>
  <h1>{props.namE}</h1>
  <h1>{props.agE}</h1>
</div>
)}; 
const param = {
  salary: 10,
  position: "intern",
  company: "kBR"
};
const Job = (param) => {
  return(
    <div>
      <h1>{param.salary}</h1>
      <h2>{param.position}</h2>
      <h3>{param.company}</h3>
    </div>
  )
};
//react component, better than storing it all in varibles
//Needs to start with captial letter

export default App;