//Shows useEffect & fetching data
import './App.css'; //can import file instead of linking it
import Axios from "axios"
import { useState,useEffect } from 'react';


/*fetch('https://catfact.ninja/fact').then((res) => res.json())
.then((data) => {
  console.log(data);
}) 
//used to fetch data from an API & THEN stores it in res and makes it into a JavaScript object form JSON
//then stores JS object in data*/


function App() {
  //API is a written code that is not apart of our specifc project

  const [catFact, setCatFact] = useState("");


  const fetchFact = () => {
    Axios.get('https://catfact.ninja/fact').then((res) => {setCatFact(res.data.fact);})
    //Axios fetches the API and automatically converts it to JS object so we can present data
  }
  
  useEffect(() => {
    fetchFact();
    //Shows twice because component mounts the unmounts then mounts again. It is infinitely fetching data
  },[]) //shows twice to make sure to protect memory leaks

  return (<div className="App">
    <button onClick={fetchFact}>Generate Cat Fact</button>
    <p>{catFact}</p>
  </div>);
}

//Lifecycle explains everything that happens to the birth/death to a component
//Three stages: Mounting, Updating, and Unmounting
//Mounting is the component starting to appear/exist in your project

//useEffect(() => {
  //useEffect shows when a component is mounted/unmounted
//  return // returns when unmounts 
//}, []); empty array can put an object and shows updating 

export default App;