import { useContext, useState } from "react";
import { AppContext } from "../App";

export const ChangeProfile = () => {
    const {setUserName} = useContext(AppContext);
    const [newUser, setUser] = useState("");
    return (
        <div>
            <input onChange={(event) => {
                setUser(event.target.value);
            }}/>
            <button onClick={() => {setUserName(newUser)}}>Change Username</button>
        </div>
    );
};