import {useForm} from "react-hook-form";
import * as yup from 'yup';
import {yupResolver} from '@hookform/resolvers/yup'

export const Form = () => {
    const schema = yup.object().shape({
        fullName: yup.string().required("Full Name is Required"), //this message shows if user tries to submit without name field
        //Enforces that when we submit fullName it is a string and it is required to put in name
        email: yup.string().email().required(),
        age: yup.number().positive().integer().min(18).required(),
        password: yup.string().min(4).max(20).required(),
        confirmPassword: yup.string().oneOf([yup.ref("password"),null, "Passwords are not equal"]).required(), //oneOf wants confirmPassword to be oneOf(equal to password)
    });
    const{register,handleSubmit,formState: {errors}} = useForm({resolver:yupResolver(schema)}); //We are telling the form that it should take the format of schema
    const onSubmit = (data) => {console.log(data);};
    return(
        <form onSubmit={handleSubmit(onSubmit)}>
            <input type="text" placeholder="Full Name..." {...register("fullName")}/>
            <p>{errors.fullName?.message}</p> {/*Displays any error messages that may occur for the fullname input */}
            <input type="text" placeholder="Email..." {...register("email")}/>
            <input type="text" placeholder="Age..." {...register("age")}/>
            <input type="password" placeholder="Password..." {...register("password")}/>
            <input type="password" placeholder="Confirm Password..." {...register("confirmPassword")} />
            <input type="Submit"/>
        </form>
    );
};