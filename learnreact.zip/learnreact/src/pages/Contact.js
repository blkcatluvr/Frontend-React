import { useContext } from "react";
import {AppContext} from '../App'

export const Contact = () => {
    const {userName} = useContext(AppContext);
    return <h1>CONTACT PAGE FOR: {userName}</h1>
};