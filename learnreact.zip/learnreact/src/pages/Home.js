import { useContext } from "react"; 
import { useQuery} from '@tanstack/react-query';
import {AppContext} from '../App';
import Axios from "axios";
import { useGetCat } from "./useGetCat";

export const Home = () => {
    const {userName} = useContext(AppContext);
    const {catData, isLoading, refetch} = useGetCat();

    if (isLoading){return <h1>is Loading</h1>;} 

    return (
    <h1>THIS IS THE HOME PAGE FOR: {userName} 
    <p>{catData?.fact}</p>
    <button onClick={refetch}>Refresh</button>
    </h1>)
};