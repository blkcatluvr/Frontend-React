import {Link} from "react-router-dom"

export const Navbar =  () => {
    return (
        <div>
            <Link to='/'>Home</Link> {/*Similar to a tag and links website to other pages*/}
            <Link to='/profile'>Profile</Link> {/*Similar to a tag and links website to other pages*/}
            <Link to='/contact'>Contact</Link>
        </div> 
    );
};