import { ChangeProfile } from "../components/ChangeProfile";
import { AppContext } from "../App";
import { useContext } from "react";

export const Profile = () => {
    const {userName,setUserName} = useContext(AppContext);
    return (
        <div>
            Profile User: {userName} 
            <ChangeProfile />
        </div>
    )
};