import Axios from "axios";
import { useQuery} from '@tanstack/react-query';
export const useGetCat = () => {
    const { data: catData, isLoading, refetch } = useQuery(["cat"], () => {
        return Axios.get('https://catfact.ninja/fact').then((res) => res.data);
        {/*Cat is the unique id representing {data} */};
    });

    return {catData, isLoading, refetch};
}