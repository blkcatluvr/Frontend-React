import './App.css'; //can import file instead of linking it
import Axios from "axios";
import {BrowserRouter as Router, Route, Routes,Link } from 'react-router-dom';
import { useState,useEffect } from 'react';
import {Home} from "./pages/Home";
import { Navbar } from './pages/Navbar';


function App() {
  return (<div className="App">
    <Router> {/*Any tags in this bar encompass all routes */}
      <Navbar />
      <Routes> {/*Has all routes fit inside this tag*/}
        <Route path="/" element={<Home />}/> {/*Mainpage of website, Element is a component to be rendeered when we load route*/}
        <Route path="*" element={<h1>Page Not Found</h1>}/> {/*Having an * means that anything you put in the element will display when an error occurs*/}
        {/*Can display different components based on which page of the UI we are in */}
      </Routes>
    </Router>
  </div>);
}


export default App;
