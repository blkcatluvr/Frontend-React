import './App.css'; //can import file instead of linking it
import {useState} from "react";

function App() {
  let [age, setAge] = useState(0); // created a state in the variable age and can use setAge to change it.
  const [inputVal, setinputVal] = useState("");
  const [showtxt, setShowText] = useState(true);
  let [count, setCount] = useState(0);
  const increaseAge = () => {setAge(age += 1);}
  const inputChange = (event) => {setinputVal(event.target.value);}
  return (<div className="App">
    {age}
    <button onClick={increaseAge}>+ Age</button>
    <div>
      <input type='text' onChange={inputChange}/>
      {inputVal}
    </div>
    <button onClick={() => {setShowText(!showtxt);}}>SHOW/HIDE</button>
    {showtxt && <h1>HI MY NAME IS MYLES</h1>}
    <div>
      {count}
      <button onClick={() => {setCount(count+=1)}}>Increase</button>
      <button onClick={() => {setCount(count-=1)}}>Decrease</button>
      <button onClick={() => {setCount(0)}}>Set 2 Zero</button>
    </div>
  </div>);
}

export default App;
