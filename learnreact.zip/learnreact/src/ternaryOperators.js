import './App.css'; //can import file instead of linking it
import { Users } from './User';
import { Planets  } from './User';

const age = 19; age >= 18 ? console.log("of age") : console.log('underage');
//ternary operator

function App() {
  const age = 19; 
  const names = ["Isacc","Chris", "Makayla"];
  const users = [
    {name:"Isacc ", age:20},
    {name:"Chris ", age:20},
    {name:"Makayla ", age:20},
  ]
  const planets = [
    {name:"Mars", isGasPlanet:false},
    {name:"Earth", isGasPlanet:false},
    {name:"Jupiter", isGasPlanet:true},
    {name:"Venus", isGasPlanet:false},
    {name:"Neptune", isGasPlanet:true},
    {name:"Uranus", isGasPlanet:true},
  ]
  const isGreen = true
  return (
  <div className="App">
    {age >= 18 ? <h1>OVER AGE</h1> : <h1>UNDER AGE</h1>}
    <h1 style={{color: isGreen ? "green" : "red" }}>Myles</h1>
    {!isGreen && <button>hi</button>} {/*Can also use && as if statement */}
    <h1>{names[0]}</h1>
    {names.map((value,key) =>{return <h1>{value}</h1>})}
    {users.map((value,key) =>{return <Users name={value.name} age={value.age}/>})}
    {planets.map((planet,key) => {return planet.isGasPlanet && <Planets name={planet.name}/>})}
    {/*Same as forEach and creates a new h1 tag for each list*/}
  </div>);
}
export default App;