import './App.css'; //can import file instead of linking it
import {useState} from "react";
import { Tasks } from './Task';

function App() {
  let [toDo,addToList] = useState([]);
  let [inputVal, setinputVal] = useState("");
  const inputChange = (event) => {setinputVal(event.target.value);};
  
  const addTask = () => {
    const task = {
      id: toDo.length === 0 ? 1 : toDo[toDo.length-1].id + 1,
      taskName: inputVal,
      complete: false
    };
    addToList([...toDo,task]);
  } //adds inputVal to toDo
  
  const deleteTask = (id) => {
    const newToDo = toDo.filter((task) => {return task.id !== id;});
    addToList(newToDo);
  }

  const completeTask = (id) => {
    const newToDo = toDo.filter((task) => {
      task.id === id && (task.complete = true);
      return task;
    });
    addToList(newToDo);
  }

  return (<div className="App">
    <div className="addTask">
      <input type='text' onChange={inputChange}/>
      <button onClick={addTask}>Add Task</button>
    </div>
    <div className="list">
      {toDo.map((value) => {return (
        <Tasks 
          taskName = {value.taskName} 
          id = {value.id} 
          deleteTask = {deleteTask}
          complete = {value.complete}
          completeTask = {completeTask}
        />
      )
    })}
    </div>
  </div>);
}

/*const Task = (props) => {
  <div>
      <h1>{props.taskName}</h1>
      <button onClick={() => props.deleteTask(props.id)}>Delete Task</button>
  </div>
}*/


export default App;
