import './App.css'; //can import file instead of linking it
import { useState } from 'react'; //hooks are functions that abstract logic in react
import { useToggle } from './useToggle';
//diff between a function and hook means we would not be able to access a state of a function


//query is read, mutation mutation is create/update/delete
function App() {
  const [isVisible,toggle] = useToggle(); //from useToggle we created we can now use any name we would like
  return (<div className="App">
    <button onClick={toggle}>
      {isVisible ? "Hide": "Show"}
    </button>
    {isVisible && <h1>Hidden Text</h1>}
  </div>);
}


export default App;
