//custom hook making
import { useContext,useEffect,useState } from "react"
export const useToggle = (initialVal = false) => { //default val if nothing passed is false
    const [state, setState] = useState(initialVal);
    const toggle = () => {
        setState((prev) => !prev);
    }
    return [state, toggle]
}