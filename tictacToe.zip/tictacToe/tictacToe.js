document.querySelector('.gameContainer').style.visibility='hidden' 
const box = document.querySelectorAll('.square');
box.forEach(function(value){
    value.addEventListener("click",() => {
        value.innerHTML = user; value.style.color = 'red';
        let win = checkWin(user);
        if(win !== true){CPUMOVE(); checkWin(CPU);}
    });
});
let user; let CPU;
function choosePlayer(player,opponent){
    user = player; CPU = opponent;
    document.querySelector('.header').innerHTML = '';
    document.querySelector('.gameContainer').style.visibility='visible' 
}
function CPUMOVE(){
    let column = columnXrowSelect(); let row = columnXrowSelect();
    space = document.querySelector(`.${column}.${row}`);
    if(space.innerHTML == ''){space.innerHTML = CPU; space.style.color = "blue"; return;}
    for(let x=0; x < box.length;x++){
        let value = box[x];
        if(value.innerHTML === ''){value.innerHTML = CPU; value.style.color = "blue"; break;}
    }
}
function columnXrowSelect(){
    let val = Math.floor(Math.random() *3)+1;
    if(val === 1){return 'one';}
    else if(val === 2){return 'two';}
    else{return 'three';}
}
let arr = [[],[],[]];
function checkWin(winner){
    let count = 0;
    for(i = 0; i < 3; i++ ){
        for(x = 0; x < 3; x++){
            arr[i][x] = box[count].innerHTML;
            count += 1;
        } 
    } 
    for(i = 0; i < 3; i++ ){
        count = true;
        for(x = 0; x < 3; x++){
            if(arr[i][x] !== winner){
                count = false; break;
            }
        }
        if(count == true){return Won(winner);}  
    }
    for(i = 0; i < 3; i++ ){
        count = true;
        for(x = 0; x < 3; x++){
            if(arr[x][i] !== winner){
                count = false; break;
            }
        }
        if(count == true){return Won(winner);}  
    }
    for (i = 0; i < 3; i++) {
        count = true;
        if (arr[i][i] !== winner) {
            count = false; break;
        }
        if (count == true && i === 2) { return Won(winner); }
    }
    x = 3;
    for (i = 0; i < 3; i++) {
        count = true; x -= 1;
        if (arr[i][x] !== winner) {
            count = false; break;
        }
        if (count == true && i === 2) { return Won(winner); }
    }
    return false;
}
function Won(winner){
    document.querySelector('.gameContainer').innerHTML = 
    '<button class="playAgain" onclick="location.reload();">Play Again?</button>';
    if(winner === user){document.querySelector('.header').innerHTML = `You Won!`; }
    else{document.querySelector('.header').innerHTML = `You Lost..`; }  
    box.forEach(function(value){value.innerHTML = '';});
    return true;
}