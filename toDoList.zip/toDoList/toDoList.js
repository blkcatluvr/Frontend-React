const toDoList = [];
function checkKey(key){
    if(key === 'Enter'){addToList();}
}
function addToList(){
    const name = document.querySelector('.js-input').value;
    const dueDate = document.querySelector('.js-date').value;
    toDoList.push({
        name,
        dueDate
    });
    printResult();
    document.querySelector('.js-input').value = '';
    document.querySelector('.js-date').value = '';
}
function printResult(){
    let div = '';
    document.querySelector('.js-toDoContainer').innerHTML = '';
    for(i = 0; i < toDoList.length; i++){
        const name = toDoList[i].name; const date = toDoList[i].dueDate; 
        div += `
        <div>${name}</div>
        <div>${date}</div> 
        <button class="deleteButton" onclick="toDoList.splice(${i},1); printResult();">
        Delete</button>
        `;
    }
    document.querySelector('.js-toDoContainer').innerHTML = div;
}

document.querySelector('.clearButton').addEventListener("click", () => {
    document.querySelectorAll('.deleteButton').forEach(function(value){
        let index = 0;
        toDoList.splice(index,1);
    });
    printResult();
});